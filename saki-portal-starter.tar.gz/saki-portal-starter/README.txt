Starter del portal de clientes SAKI con Supabase + Next.js.
Subilo a tu repo en GitHub y descomprimilo para empezar.
